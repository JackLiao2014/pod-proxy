# TensorFlow Lite for iOS
- For Swift developers, add the `TensorFlowLiteSwift` pod to your Podfile. For
  Objective-C developers, add `TensorFlowLiteObjC`. See the TensorFlow Lite
  [Swift](https://github.com/tensorflow/tensorflow/tree/master/tensorflow/lite/swift)
  and
  [ObjC](https://github.com/tensorflow/tensorflow/tree/master/tensorflow/lite/objc)
  directories for more details.
